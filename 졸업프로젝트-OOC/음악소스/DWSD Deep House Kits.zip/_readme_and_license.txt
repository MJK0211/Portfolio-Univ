Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by the following user:
 - DWSD ( https://www.freesound.org/people/DWSD/ )

You can find this pack online at: https://www.freesound.org/people/DWSD/packs/11575/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 183125__dwsd__prc-dust808popperc.wav
    * url: https://www.freesound.org/s/183125/
    * license: Attribution
  * 183124__dwsd__prc-dust808tomlow.wav
    * url: https://www.freesound.org/s/183124/
    * license: Attribution
  * 183123__dwsd__prc-appetizer.wav
    * url: https://www.freesound.org/s/183123/
    * license: Attribution
  * 183122__dwsd__prc-appetom.wav
    * url: https://www.freesound.org/s/183122/
    * license: Attribution
  * 183121__dwsd__prc-detailedperk.wav
    * url: https://www.freesound.org/s/183121/
    * license: Attribution
  * 183120__dwsd__prc-dust808clav.wav
    * url: https://www.freesound.org/s/183120/
    * license: Attribution
  * 183119__dwsd__hat-detailedopen909.wav
    * url: https://www.freesound.org/s/183119/
    * license: Attribution
  * 183118__dwsd__hat-doitliveopenhat.wav
    * url: https://www.freesound.org/s/183118/
    * license: Attribution
  * 183117__dwsd__hat-dust808.wav
    * url: https://www.freesound.org/s/183117/
    * license: Attribution
  * 183115__dwsd__prc-appet909.wav
    * url: https://www.freesound.org/s/183115/
    * license: Attribution
  * 183114__dwsd__snr-appetizer.wav
    * url: https://www.freesound.org/s/183114/
    * license: Attribution
  * 183113__dwsd__rim-doitlivebias.wav
    * url: https://www.freesound.org/s/183113/
    * license: Attribution
  * 183112__dwsd__snr-detailroom.wav
    * url: https://www.freesound.org/s/183112/
    * license: Attribution
  * 183111__dwsd__snr-bod.wav
    * url: https://www.freesound.org/s/183111/
    * license: Attribution
  * 183110__dwsd__ride-dust808.wav
    * url: https://www.freesound.org/s/183110/
    * license: Attribution
  * 183109__dwsd__prc-phat909roomtom.wav
    * url: https://www.freesound.org/s/183109/
    * license: Attribution
  * 183108__dwsd__rim-boda.wav
    * url: https://www.freesound.org/s/183108/
    * license: Attribution
  * 183107__dwsd__rim-909analog.wav
    * url: https://www.freesound.org/s/183107/
    * license: Attribution
  * 183106__dwsd__snr-doitlive.wav
    * url: https://www.freesound.org/s/183106/
    * license: Attribution
  * 183105__dwsd__hat-appetizer.wav
    * url: https://www.freesound.org/s/183105/
    * license: Attribution
  * 183104__dwsd__hat-bodacious.wav
    * url: https://www.freesound.org/s/183104/
    * license: Attribution
  * 183103__dwsd__clp-appetizer.wav
    * url: https://www.freesound.org/s/183103/
    * license: Attribution
  * 183102__dwsd__clp-bodacious.wav
    * url: https://www.freesound.org/s/183102/
    * license: Attribution
  * 183101__dwsd__clp-detailed.wav
    * url: https://www.freesound.org/s/183101/
    * license: Attribution
  * 183100__dwsd__clp-dust808.wav
    * url: https://www.freesound.org/s/183100/
    * license: Attribution
  * 183099__dwsd__bd-bodacious.wav
    * url: https://www.freesound.org/s/183099/
    * license: Attribution
  * 183098__dwsd__bd-detailed.wav
    * url: https://www.freesound.org/s/183098/
    * license: Attribution
  * 183097__dwsd__bd-doitlive.wav
    * url: https://www.freesound.org/s/183097/
    * license: Attribution
  * 183096__dwsd__bd-dust808.wav
    * url: https://www.freesound.org/s/183096/
    * license: Attribution


